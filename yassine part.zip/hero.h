/**
* @file hero.h
* @brief  fichier header
* @author NOT YET Yassine Ben Salha + Yassmine Slitti + Nahed Ben Kacem 1A3
* @version 1.2
* @date June 2020
*/
#ifndef HERO_H_INCLUDED
#define HERO_H_INCLUDED
#include <SDL/SDL_ttf.h>

/**
* @struct vie
* @brief structure vie
*/
struct vie
{
	SDL_Surface *vie;
	SDL_Rect positionvie;
	int updatevie;
};
typedef struct vie vie;

/**
* @struct herops
* @brief structure heros
*/
struct heros
{
	int mouselocation,frame,directionmouse,compteurmouse;
	SDL_Surface *heroright;
	SDL_Surface *heroleft;
	SDL_Surface *heroshooting;
	SDL_Surface *bullet;
	SDL_Surface *obtaingun;
	SDL_Rect obtaingunposition;
	SDL_Rect heroposition;
	SDL_Rect bulletposition;
	SDL_Rect rectsright[5],rectsleft[5],rectshoot[1];
	SDL_Rect herorelativeposition;
	int speedup,speeddown,directionjump,ground,gravity,shootframe,shoot,initbullet;
	int herospeed;
	int heroisjumping;
	int accelerate;
	int choixhero;
	
};
typedef struct heros heros; 

/**
* @struct minihero
* @brief structure minihero
*/
struct minihero
{
	SDL_Surface *minihero;
	SDL_Surface *minimap;
	SDL_Surface *minimapfocus;
	SDL_Rect miniheroposition;
	SDL_Rect positionminimap;
	SDL_Rect positionfocus;

	int directiondep;
	int temps;
	
};
typedef struct minihero minihero;

/**
* @struct camera
* @brief structure camera
*/
struct camera
{
	SDL_Rect camera;
}; 
typedef struct camera camera;

/**
* @struct score
* @brief structure score
*/
struct score
{
	SDL_Surface *text;
	SDL_Rect positionscore;
	int score;
	TTF_Font *police;


};
typedef struct score score;

void choixhero (heros* hero,SDL_Surface* screen );

void init (score* s);
void affichage_score (score* s,char score[]);


void initvie ( vie* v);
void updatevie(vie* v);
void blitvie( vie* v,SDL_Surface *screen);


void vongratswin(heros* hero,SDL_Surface *screen);

void mousemovement (heros* hero,camera* c,SDL_Surface *screen,SDL_Rect positionMenu1,SDL_Surface *menu1);

int arduinoWriteData(int x);
int arduinoReadData(int *x);
void jouer(SDL_Surface* screen);
void initialisation(heros* hero);

void setrectsright(heros* hero);
void setrectsleft(heros* hero);
void setrectshoot(heros* hero);

void setrectsright2(heros* hero);
void setrectsleft2(heros* hero);
void setrectshoot2(heros* hero);

void shooting ( heros* hero,SDL_Surface *screen);
void bulletanimation( heros* hero);

void hero_final_mouvement(heros* hero,int choix );
void deplacerjoueur(heros* hero ,int choixdeplacement);
void blitfenetre(SDL_Rect positionMenu1,SDL_Surface *screen,int choix,SDL_Surface *menu1,heros* hero,camera* c);
void speed(heros* hero);

void resetafterjump ( heros* hero,camera* c);
void jump (heros* hero);
void restart_jump ( heros* hero ) ;

void initcamera ( camera* c);
void scrolling (camera* c,heros* hero);
void scrollingb (camera* c,heros* hero);

void jump_minihero(minihero* mh,heros* hero);
void initialiserminihero(minihero* mh,heros* hero);
void blitminihero(SDL_Surface *screen,minihero* mh);
void deplacer ( minihero* mh,heros* hero);

#endif // HERO_H_INCLUDED
