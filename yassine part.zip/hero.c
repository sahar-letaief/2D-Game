/**
* @file hero.c
* @brief  fichier source 
* @author NOT YET Yassine Ben Salha + Yassmine Slitti + Nahed Ben Kacem 1A3
* @version 1.2
* @date June 2020
*/

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <math.h>
#include <time.h>
#include "string.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "hero.h"
#include "enemie.h"


/**
* @brief fonction qui sert à identifier l'hero selon le choix du joueur
* @param hero de type heros,screen
* @return nothing
*/
void choixhero (heros* hero,SDL_Surface* screen )
{
int cont = 0 ;

while (cont!=1)
{
SDL_Surface* bg = IMG_Load("blur.png");
SDL_Rect posbg;
posbg.x = 0;
posbg.y = 0;


SDL_Surface* choixhero1 = IMG_Load("heropick.png");
SDL_Rect positionchoix;

positionchoix.x = 300;
positionchoix.y = 200;

int x,y;

SDL_BlitSurface(bg,NULL,screen,&posbg);
SDL_BlitSurface(choixhero1,NULL,screen,&positionchoix);
SDL_Flip(screen);
        SDL_Event event;
       SDL_WaitEvent(&event);
            if(event.type==SDL_MOUSEBUTTONDOWN)
            {
                        if(event.button.button==SDL_BUTTON_LEFT)
                          {
				x = event.button.x;
				y = event.button.y;

				if ( (x>=380)&&(x<=515)&&(y>=280)&&(y<=580) )
				{
					hero->choixhero = 1;
					cont = 1;
					choixhero1 = NULL;
				}

				if ( (x>=647)&&(x<=777)&&(y>=280)&&(y<=582) )
				{
					hero->choixhero = 2;
					cont = 1;
					choixhero1 = NULL;
				}

			  }
	    }


SDL_FreeSurface(choixhero1);
}


}



/**
* @brief fonction jouer qui sert à la communication SDL/arduino
* @param int x 
* @return int
*/
int arduinoWriteData(int x)
{
    char chemin[]="/dev/ttyACM0";
    FILE*f;

    f=fopen(chemin,"w");
    if(f == NULL)
        return(-1);

    fprintf(f,"%d",x);
    fclose(f);

    return(0);
}
/**
* @brief fonction jouer qui sert à la communication arduino/SDL
* @param int *x 
* @return int
*/
int arduinoReadData(int *x)
{
    char chemin[]="/dev/ttyACM0";
    FILE*f;
    char c;
    f=fopen(chemin,"r");
if(f == NULL){
printf("NULL\n");
        return(0);
}
    fscanf(f,"%d",x);
printf("fscanf %d\n",(*x));
    fclose(f);

    return(*x);
}

/**
* @brief fonction qui initialise la variable v
* @param v de type vie
* @return nothing
*/
void initvie ( vie* v)
{
	v->vie = NULL;
	v->positionvie.x = 10;
	v->positionvie.y = 20;
	v->vie = IMG_Load("live1.png");
	v->updatevie = 0;
}
/**
* @brief fonction jouer qui sert à la mise à jour de la variable v
* @param v de type vie*
* @return nothing
*/
void updatevie(vie* v)
{
	if ( v->updatevie >= 3 )
	{
		v->updatevie = 0 ;
	}
	
	if ( v->updatevie == 0 ) 
	{
		SDL_FreeSurface(v->vie);
		v->vie = NULL;
		v->vie = IMG_Load("live1.png");

	}


	if ( v->updatevie == 1 ) 
	{
		SDL_FreeSurface(v->vie);
		v->vie = NULL;
		v->vie = IMG_Load("live2.png");

	}
	if ( v->updatevie == 2 ) 
	{
		SDL_FreeSurface(v->vie);
		v->vie = NULL;
		v->vie = IMG_Load("live3.png");
	}
}
/**
* @brief fonction jouer qui sert à blitter(afficher la vie)
* @param v,screen
* @return nothing
*/
void blitvie( vie* v,SDL_Surface *screen)
{
		SDL_BlitSurface(v->vie,NULL,screen,&(v->positionvie));	
}

/**
* @brief fonction qui sert à mouvementer l'hero avec souris
* @param hero,c,screen,positionMenu1,menu1
* @return nothing
*/
void mousemovement (heros* hero,camera* c,SDL_Surface *screen,SDL_Rect positionMenu1,SDL_Surface *menu1)
{
if ( hero->mouselocation != 0 )
{
switch ( hero->directionmouse ) 
{
	case 1 :
	{
		if ( hero->compteurmouse >= 10 ) 
		{
			printf("compteurrrrr %d\n",hero->compteurmouse);
			deplacerjoueur(hero,1);
			scrolling (c,hero);
			printf("cameraaaa %d\n",c->camera.x);
			hero->compteurmouse -= 10 ;
			blitfenetre(positionMenu1,screen,1,menu1,hero,c);
		}
		if ( hero->compteurmouse <= 10 )
		{
			hero->mouselocation = 0;
		}
	}break;
		
	case 2 :
	{
		if ( hero->compteurmouse >= 10 ) 
		{
			deplacerjoueur(hero,2);
			scrollingb (c,hero);
			hero->compteurmouse -= 10 ;
			blitfenetre(positionMenu1,screen,2,menu1,hero,c);
		}
		if ( hero->compteurmouse <= 10 )
		{
			hero->mouselocation = 0;
		}
	}break;

}//switch
}//ifmouse
}//void

/**
* @brief fonction qui sert à mouvementer l'hero avec souris
* @param hero,screen
* @return nothing
*/
void vongratswin(heros* hero,SDL_Surface *screen)
{
	int n = 0 ;
	
	hero->obtaingun = IMG_Load("obtaingun1.png");
	hero->obtaingunposition.x = 400;
	hero->obtaingunposition.y =350;
	SDL_BlitSurface(hero->obtaingun,NULL,screen,&(hero->obtaingunposition));
	SDL_Flip(screen);
	SDL_Delay(100);

	hero->obtaingun = NULL;
	hero->obtaingun = IMG_Load("obtaingun2.png");
	hero->obtaingunposition.x = 345;
	hero->obtaingunposition.y =350;
	SDL_BlitSurface(hero->obtaingun,NULL,screen,&(hero->obtaingunposition));
	SDL_Flip(screen);
	SDL_Delay(100);

	hero->obtaingun = NULL;
	hero->obtaingun = IMG_Load("obtaingun3.png");
	hero->obtaingunposition.x = 290;
	hero->obtaingunposition.y =350;
	SDL_BlitSurface(hero->obtaingun,NULL,screen,&(hero->obtaingunposition));
	SDL_Flip(screen);

	int temp = 4000;

	if ( SDL_GetTicks() - temp <= 50 )
	{
		hero->obtaingun = NULL;
		SDL_FreeSurface(hero->obtaingun);
	}


	SDL_Flip(screen);
}

/**
* @brief fonction qui sert à initialiser l'hero
* @param hero
* @return nothing
*/
void initialisation(heros* hero)
{
    hero->obtaingun = NULL;
    hero->heroshooting = NULL;
    hero->heroright = NULL;
    hero->heroleft = NULL;
    hero->bullet = NULL;
    hero->mouselocation = 0;
    hero->frame = 0;
    hero->directionmouse = 0;
	if ( hero->choixhero == 1 )
	{
    hero->heroright = IMG_Load("right.png");
    hero->heroleft = IMG_Load("left.png");
    hero->heroshooting = IMG_Load("heroshooting.png");
    	}
	if ( hero->choixhero == 2 )
	{
    hero->heroright = IMG_Load("right2.png");
    hero->heroleft = IMG_Load("left2.png");
    hero->heroshooting = IMG_Load("heroshooting2.png");
	}

    hero->bullet = IMG_Load("bullet.png");
    hero->bulletposition.x = 0;
    hero->bulletposition.y = 0;
    hero->heroposition.x = 100;
    hero->heroposition.y = 600;
    hero->speedup = 1 ;
    hero->speeddown = 20 ;
    hero->directionjump = 1;
    hero->ground = 600 ;
    hero->gravity = 0;
    hero->herospeed=0;
    hero->heroisjumping = 0;
    hero->shootframe = 0;
    hero->shoot = 0;
    hero->compteurmouse = 0;
    hero->initbullet = 0;
    hero->accelerate = 15 ;
    hero->obtaingunposition.x = 0;
    hero->obtaingunposition.y = 0;
    hero->choixhero = 1 ;



}

void bulletanimation( heros* hero)
{
	if ( hero->initbullet == 0 )
	{
		hero->bulletposition.x = hero->heroposition.x + 35;
		hero->bulletposition.y = hero->heroposition.y + 93;
		hero->initbullet = 1;
	}
	hero->bulletposition.x += 50 ;

	if ( hero->bulletposition.x >= hero->heroposition.x + 200 )
	{
		hero->initbullet = 0;
	}
	
}

/**
* @brief fonction qui sert à animer le spritesheet du shooting
* @param hero,screen
* @return nothing
*/
void shooting ( heros* hero,SDL_Surface *screen)
{
	hero->frame = 0;
	if ( hero->shootframe <= 1 )
	{
		hero->shootframe = hero->shootframe + 1 ;
	}
	if ( hero->shootframe >= 2 )
	{
		hero->shootframe = 0;
	}


	SDL_BlitSurface(hero->bullet,NULL,screen,&(hero->bulletposition));

	SDL_BlitSurface(hero->heroshooting,&(hero->rectshoot[hero->shootframe]), screen, &(hero->heroposition));





}

/**
* @brief fonction qui sert à initialiser les spritesheets du shoot1
* @param hero
* @return nothing
*/
void setrectshoot(heros* hero)
{
	hero->rectshoot[0].x = 0;
	hero->rectshoot[0].y = 0;
	hero->rectshoot[0].w = 62;
	hero->rectshoot[0].h = 150;

	hero->rectshoot[1].x = 64;
	hero->rectshoot[1].y = 0;
	hero->rectshoot[1].w = 84;
	hero->rectshoot[1].h = 150;
}

/**
* @brief fonction qui sert à initialiser les spritesheet du hero1 à gauche
* @param hero
* @return nothing
*/
void setrectsleft(heros* hero)
{
   
        hero->rectsleft[0].x = 282;
        hero->rectsleft[0].y = 0;
        hero->rectsleft[0].w = 50;
        hero->rectsleft[0].h = 150;

        hero->rectsleft[1].x = 232;
        hero->rectsleft[1].y = 0;
        hero->rectsleft[1].w = 48;
        hero->rectsleft[1].h = 150;

        hero->rectsleft[2].x = 171;
        hero->rectsleft[2].y = 0;
        hero->rectsleft[2].w = 57;
        hero->rectsleft[2].h = 150;

        hero->rectsleft[3].x = 115;
        hero->rectsleft[3].y = 0;
        hero->rectsleft[3].w = 53;
        hero->rectsleft[3].h = 150;

        hero->rectsleft[4].x = 54;
        hero->rectsleft[4].y = 0;
        hero->rectsleft[4].w = 59;
        hero->rectsleft[4].h = 150;

        hero->rectsleft[5].x = 0;
        hero->rectsleft[5].y = 0;
        hero->rectsleft[5].w = 48;
        hero->rectsleft[5].h = 150;
    
}

/**
* @brief fonction qui sert à initialiser les spritesheets du hero1 à droite
* @param hero
* @return nothing
*/
void setrectsright(heros* hero)
{
    hero->rectsright[0].x = 0 ;
    hero->rectsright[0].y = 0;
    hero->rectsright[0].w = 50;
    hero->rectsright[0].h = 150;

    hero->rectsright[1].x = 55 ;
    hero->rectsright[1].y = 0;
    hero->rectsright[1].w = 48;
    hero->rectsright[1].h = 150;

    hero->rectsright[2].x = 104 ;
    hero->rectsright[2].y = 0;
    hero->rectsright[2].w = 57;
    hero->rectsright[2].h = 150;

    hero->rectsright[3].x = 164;
    hero->rectsright[3].y = 0;
    hero->rectsright[3].w = 53;
    hero->rectsright[3].h = 150;

    hero->rectsright[4].x = 220 ;
    hero->rectsright[4].y = 0;
    hero->rectsright[4].w = 59;
    hero->rectsright[4].h = 150;


}

/////////////////////////////////////////////////////////


/**
* @brief fonction qui sert à initialiser les spritesheet du hero2 à droite
* @param hero
* @return nothing
*/
void setrectsright2(heros* hero)
{
    hero->rectsright[0].x = 0 ;
    hero->rectsright[0].y = 0;
    hero->rectsright[0].w = 52;
    hero->rectsright[0].h = 150;

    hero->rectsright[1].x = 54 ;
    hero->rectsright[1].y = 0;
    hero->rectsright[1].w = 50;
    hero->rectsright[1].h = 150;

    hero->rectsright[2].x = 106 ;
    hero->rectsright[2].y = 0;
    hero->rectsright[2].w = 60;
    hero->rectsright[2].h = 150;

    hero->rectsright[3].x = 166;
    hero->rectsright[3].y = 0;
    hero->rectsright[3].w = 55;
    hero->rectsright[3].h = 150;

    hero->rectsright[4].x = 220 ;
    hero->rectsright[4].y = 0;
    hero->rectsright[4].w = 57;
    hero->rectsright[4].h = 150;

    hero->rectsright[5].x = 283;
    hero->rectsright[5].y = 0;
    hero->rectsright[5].w = 49;
    hero->rectsright[5].h = 150;
}

/**
* @brief fonction qui sert à initialiser les spritesheet du hero2 à gauche
* @param hero
* @return nothing
*/

void setrectsleft2(heros* hero)
{
   
        hero->rectsleft[0].x = 287;
        hero->rectsleft[0].y = 0;
        hero->rectsleft[0].w = 52;
        hero->rectsleft[0].h = 150;

        hero->rectsleft[1].x = 233;
        hero->rectsleft[1].y = 0;
        hero->rectsleft[1].w = 50;
        hero->rectsleft[1].h = 150;

        hero->rectsleft[2].x = 173;
        hero->rectsleft[2].y = 0;
        hero->rectsleft[2].w = 60;
        hero->rectsleft[2].h = 150;

        hero->rectsleft[3].x = 115;
        hero->rectsleft[3].y = 0;
        hero->rectsleft[3].w = 55;
        hero->rectsleft[3].h = 150;

        hero->rectsleft[4].x = 53;
        hero->rectsleft[4].y = 0;
        hero->rectsleft[4].w = 57;
        hero->rectsleft[4].h = 150;

        hero->rectsleft[5].x = 0;
        hero->rectsleft[5].y = 0;
        hero->rectsleft[5].w = 49;
        hero->rectsleft[5].h = 150;
    
}

/**
* @brief fonction qui sert à initialiser les spritesheet du shoot2
* @param hero
* @return nothing
*/
void setrectshoot2(heros* hero)
{
	hero->rectshoot[0].x = 0;
	hero->rectshoot[0].y = 0;
	hero->rectshoot[0].w = 60;
	hero->rectshoot[0].h = 150;

	hero->rectshoot[1].x = 61;
	hero->rectshoot[1].y = 0;
	hero->rectshoot[1].w = 80;
	hero->rectshoot[1].h = 150;
}


/**
* @brief fonction qui sert à identifier le mouvement du hero (à gauche/à droite)
* @param hero,choix 
* @return nothing
*/
void hero_final_mouvement(heros* hero,int choix )
{
    switch(choix)
    {
    case 1 :
    {

        hero->heroposition.x+=10;


    }
    break;

    case 2 :
    {

        hero->heroposition.x-=10;

    }
    break;

    }
    SDL_Delay(70);

}


/**
* @brief fonction qui sert à deplacer l'hero
* @param hero,choixdeplacement
* @return nothing
*/
void deplacerjoueur(heros* hero,int choixdeplacement)
{

    if ( hero->frame <= 5 )
    {
        hero->frame = hero->frame + 1 ;
    }
    if ( hero->frame >= 5 )
    {
        hero->frame = 0 ;
    }

    switch(choixdeplacement)
    {
    case 1 :
    {

        hero->heroposition.x+=0;


    }
    break;

    case 2 :
    {

        hero->heroposition.x-=0;

    }
    break;

    }
    SDL_Delay(70);
}
/**
* @brief fonction qui sert à revenir au point initial en cas  du bouton du jump non pressé
* @param hero,camera
* @return nothing
*/
void resetafterjump ( heros* hero,camera* c)
{
    int speeddown ;
    speeddown = hero->speeddown;
    if ( speeddown >= 1 )
    {
        speeddown -= 1;
    }
    if ( hero->heroposition.y < hero->ground )
    {
        hero->heroposition.y += (hero->heroposition.y/30)+2;
        SDL_Delay(speeddown);
    }
    if ( hero->heroposition.y >= hero->ground )
    {
        hero->heroposition.y = hero->ground;
        hero->heroisjumping = 0;
    }
    if ( (hero->directionjump == 1) &&(hero->heroisjumping == 1) )
    {
        scrolling (c,hero);
    }
    if ( (hero->directionjump == 2)&&(hero->heroisjumping == 1) )
    {
        scrollingb (c,hero);
    }
    SDL_Delay(20);
}


/**
* @brief fonction qui sert au jump de l'hero
* @param hero,choixdeplacement
* @return nothing
*/
void jump (heros* hero)
{

    if ( hero->heroisjumping == 1 )
    {
        if ( hero->gravity == 0 )
        {
            hero->heroposition.y -= (hero->heroposition.y/30)+5;
            SDL_Delay(hero->speedup);
        }
        if( hero->speedup <= 10)
        {
            hero->speedup +=1;
        }

        if ( hero->heroposition.y <= 400 )
        {
            hero->gravity = 1;
        }
        if ( hero->gravity == 1 )
        {
            SDL_Delay(hero->speeddown);
            if ( hero->speeddown >=1 )
            {
                hero->speeddown -= 1;
            }
            if ( hero->heroposition.y >= hero->ground )
            {
                hero->heroposition.y = hero->ground;
                restart_jump(hero);
                hero->heroisjumping = 0;
            }
            if ( hero->heroposition.y != hero->ground )
            {
                hero->heroposition.y += (hero->heroposition.y/30)+2;
            }
        }


    }//taskiret heroisjumping

}

/**
* @brief fonction qui sert à initialiser le jump de l'hero
* @param hero
* @return nothing
*/
void restart_jump ( heros* hero )
{
    hero->speedup = 0;
    hero->gravity = 0;
    hero->speeddown = 20;
}



/**
* @brief fonction qui sert à blitter les spritesheets du jouer selon le choix de l'utilisateur
* @param positionMenu,screen,choix,menu1,hero,c
* @return nothing
*/
void blitfenetre(SDL_Rect positionMenu1,SDL_Surface *screen,int choix,SDL_Surface *menu1,heros* hero,camera* c)
{
    switch(choix)
    {
    case 1 :
    {
        SDL_BlitSurface(menu1,&c->camera,screen,&positionMenu1);
        if ( hero->heroisjumping == 1 )
        {
            SDL_BlitSurface(hero->heroright,&(hero->rectsright[2]), screen, &(hero->heroposition));
        }
        else
            SDL_BlitSurface(hero->heroright,&(hero->rectsright[hero->frame]), screen, &(hero->heroposition));
    }
    break;

    case 2 :
    {
        SDL_BlitSurface(menu1,&c->camera,screen,&positionMenu1);
        if ( hero->heroisjumping == 1 )
        {
            SDL_BlitSurface(hero->heroleft, &(hero->rectsleft[2]), screen, &(hero->heroposition));
        }
        else
            SDL_BlitSurface(hero->heroleft, &(hero->rectsleft[hero->frame]), screen, &(hero->heroposition));
    }
    break;
    }

}

/**
* @brief fonction qui sert à la gestion de la vitesse de l'hero
* @param hero
* @return nothing
*/
void speed(heros* hero)
{
    if ( hero->herospeed <= 1 )
    {
        hero->herospeed+=1;
    }
    if ( hero->herospeed > 1 )
    {
        hero->herospeed = 0;
    }
}



////////////////////////////////////////////////////////////////////////////////////
/**
* @brief fonction qui sert à intialiser la camera
* @param c
* @return nothing
*/
void initcamera ( camera* c)
{
    c->camera.x=0;
    c->camera.y=0;
    c->camera.h=800;
    c->camera.w=1200;
}






/**
* @brief fonction qui sert au scrolling du l'hero
* @param c,hero
* @return nothing
*/
void scrolling (camera* c,heros* hero)
{

    if ( hero->heroposition.x < 300 )
    {
        hero->heroposition.x += 20;

    }
    else
    {

        if ( hero->herospeed == 0 )
        {
            c->camera.x+=10;
		if ( hero->accelerate >= 16 )
		{
			hero->accelerate = 15;
		}
        }
        if ( hero->herospeed == 1 )
        {
		if ( hero->accelerate <= 19 )
		{
			hero->accelerate += 1;
		}
            c->camera.x+=hero->accelerate;
        }

        if (c->camera.x >=8800)
        {
            c->camera.x=8800;
        }

    }
}


/**
* @brief fonction qui sert au scrolling du background
* @param c,hero
* @return nothing
*/
void scrollingb (camera* c,heros* hero)
{

    
        if ( hero->herospeed == 0 )
        {
            c->camera.x-=10;
		if ( hero->accelerate >= 16 )
		{
			hero->accelerate = 15;
		}
        }
        if ( hero->herospeed == 1 )
        {
		if ( hero->accelerate <= 19 )
		{
			hero->accelerate += 1;
		}
            c->camera.x-=hero->accelerate;
        }

     if (c->camera.x <= 10)
    {
        c->camera.x = 0;
	hero->heroposition.x -= 20;
    }

}





//////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////MINI HERO////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////

/**
* @brief fonction qui sert a initialiser le minihero
* @param mh
* @return nothing
*/
void initialiserminihero(minihero* mh,heros* hero)
{
    mh->minihero = NULL;
    mh->minimap = NULL;
    mh->minimapfocus = NULL;

    mh->temps = 0 ;



    mh->miniheroposition.x = 620;
    mh->miniheroposition.y = 175;

    mh->positionminimap.x = 600;
    mh->positionminimap.y = 100;

    mh->positionfocus.x = 600;
    mh->positionfocus.y = 100;




    mh->directiondep = 0;
if ( hero->choixhero == 1 )
{
    mh->minihero = IMG_Load("minihero1.png");
}
if ( hero->choixhero == 2 )
{
    mh->minihero = IMG_Load("minihero2.png");
} 
   mh->minimap = IMG_Load("minimap.png");
    mh->minimapfocus = IMG_Load("focusminimap.png");

}

/**
* @brief fonction qui sert a deplacer le minihero
* @param mh,hero
* @return nothing
*/
void deplacer ( minihero* mh,heros* hero)
{
mh->temps +=1;
    switch (mh->directiondep )
    {
    case 1 :
    {
if ( mh->temps%2 == 0 )
{
        if ( hero->herospeed == 0)
        {
            if( ( mh->positionfocus.x < 1100 ) && ( mh->miniheroposition.x <= 1170 ) )
            {
                mh->positionfocus.x+=1;
                mh->miniheroposition.x+=1;
            }
        }
        if ( hero->herospeed == 1)
        {
            if( ( mh->positionfocus.x < 1100 ) && ( mh->miniheroposition.x <= 1170 ) )
            {
                mh->positionfocus.x+=2;
                mh->miniheroposition.x+=2;
            }
        }
}
    }
    break;
    case 2 :
    {
if ( mh->temps%2 == 0 )
{
        if ( hero->herospeed == 0)
        {
            if( ( mh->positionfocus.x > 600 ) && ( mh->miniheroposition.x > 620 ) )
            {
                mh->positionfocus.x-=1;
                mh->miniheroposition.x-=1;
            }
        }
        if ( hero->herospeed == 1)
        {
            if( ( mh->positionfocus.x > 600 ) && ( mh->miniheroposition.x > 620 ) )
            {
                mh->positionfocus.x-=2;
                mh->miniheroposition.x-=2;
            }
        }
}
    }
    break;
    }

}
/**
* @brief to jump the mini hero 
* @param hero and minihero
* @return nothing
*/

void jump_minihero(minihero* mh,heros* hero)
{
if ( hero->heroisjumping == 1 )
{
	if ( hero->gravity == 0 )
	{
		mh->miniheroposition.y -= 1;
	}
	if ( hero->gravity == 1 )
	{
		mh->miniheroposition.y += 1;
	}
	if (mh->miniheroposition.y > 175 )
	{
 	   mh->miniheroposition.y = 175;
	}
}
}

/**
* @brief fonction qui sert à blitter le minihero
* @param screen,mh
* @return nothing
*/
void blitminihero(SDL_Surface *screen,minihero* mh)
{


    SDL_BlitSurface(mh->minimap,NULL,screen,&(mh->positionminimap) );

    SDL_BlitSurface(mh->minimapfocus,NULL,screen,&(mh->positionfocus));

    SDL_BlitSurface(mh->minihero,NULL,screen,&(mh->miniheroposition));

    SDL_Flip(screen);
}


////////////////////////////////////////////////////////////////

//////////////////////SCORE/////////////////////////////////////

////////////////////////////////////////////////////////////////


/**
* @brief fonction qui sert a initialiser le score
* @param s
* @return nothing
*/
void init (score* s)
{    
	s->text = NULL;
	s->positionscore.x = 10;
	s->positionscore.y = 150;
	s->score = 0;
	s->police = TTF_OpenFont("yass.ttf",30) ;
	


}

/**
* @brief fonction qui sert à afficher le score
* @param s
* @return nothing
*/
void affichage_score (score* s,char score[])
{    
	SDL_Color c = {255,255,255};   
            
            sprintf(score, "score : %d", s->score); /* On écrit dans la chaîne "temps" le nouveau temps */
            SDL_FreeSurface(s->text); /* On supprime la surface précédente */
            s->text = TTF_RenderText_Solid(s->police, score, c); /* On écrit la chaîne temps dans la SDL_Surface */

}
















