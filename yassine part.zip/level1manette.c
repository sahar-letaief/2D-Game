/**
* @file level1manette.c
* @brief  jouer avec manette
* @author NOT YET Yassine Ben Salha 1A3
* @version 0.1
* @date June 2020
*/
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <math.h>
#include <time.h>
#include "string.h"
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "hero.h"
#include "enemie.h"
#include "enigme1.h"
#include "enigmefichier.h"


void jouermanette(SDL_Surface* screen)
{ 
  Uint32 start;
  const int fps = 20;
  system("stty -F /dev/ttyACM0 9600 -parenb cs8 -cstopb");

    Mix_OpenAudio(22050,MIX_DEFAULT_FORMAT,2,4096);
    Mix_Chunk *coin_sound=NULL;
    Mix_Chunk *shot_sound= Mix_LoadWAV("shot_sound.wav");
    Mix_Chunk *reload_sound= Mix_LoadWAV("reload_sound.wav");

    SDL_Rect anim_enemie2[18], coin[21];
    int frame_enemie2;

    entite_second_artif enemie1;

    entite_second_fix coins[3],enemie2;

enemie_shot shot;



    int test=0,i;
	int bound = 0;
/////////////////////////////////////////////sahar

	enigmef ef;
	int argc;
	char* argv[20];

////////////////////////////////////////////////////////////nardine



    int testenigme1fois= 0, resultat = 0 ;
/////////////////////////////////////////////////////////////yesmine
    TTF_Init();
    vie v;
    initvie(&v);

    score s,s1;
    char score[20] = "";
    SDL_Color couleurblanche = {255, 255, 255};

///////////////////////////////////////////////////////////

    Mix_Chunk *machinegun=NULL;

    machinegun = Mix_LoadWAV("machine.wav");
	int r=0;

    heros hero;


    SDL_Init(SDL_INIT_EVERYTHING);
    screen = SDL_SetVideoMode(1200,800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);

    camera c;
    initcamera (&c);


    SDL_Surface   *menu1=NULL ;
    int continuer = 1;
    SDL_Rect positionMenu1;
    menu1 = IMG_Load("lvl1.png");
    positionMenu1.x=0;
    positionMenu1.y=0;

     inti_enemie(anim_enemie2, &enemie1, coins, coin,&coin_sound,&enemie2, positionMenu1,&shot);

    minihero mh;
    initialiserminihero(&mh);
	
    init (&s);
    initialisation(&hero);
    setrectsright(&hero);
    setrectsleft(&hero);
    setrectshoot(&hero);



    blitfenetre(positionMenu1,screen,1,menu1,&hero,&c);

    sprintf(score, "score : %d", s.score);
    s.text = TTF_RenderText_Solid(s.police, score, couleurblanche);


    SDL_BlitSurface(s.text, NULL, screen, &(s.positionscore)); /* Blit du texte */
    Afficher_Etites(screen,anim_enemie2,&enemie1,coins,coin,&test,&enemie2,hero.heroposition,&shot);
    blitvie(&v,screen);
    blitminihero(screen,&mh);
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
    while(continuer!=0)
    {
	start = SDL_GetTicks();
	arduinoReadData(&r);
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            switch(event.type)
            {

            case SDL_QUIT:
                continuer=0;
                break;


                    break;

                case SDLK_LSHIFT :
                    speed(&hero);
                    break;

                
            
            }

        }//taskiret pollevent

/////////////////////////////////arduino 

if ( r == 1 )
{
                    hero.directionjump = 1;
                    deplacerjoueur(&hero,1);
                    if(Bounding_Box(&hero.heroposition,&enemie2.tpos) == 1 )
                    {}
                    else
                    {
                        scrolling (&c,&hero);
                        enemie2.tpos.x-=15;
                        enemie1.tpos.x-=15;
                        coins[0].tpos.x-=15;
                        coins[1].tpos.x-=15;
                        coins[2].tpos.x-=15;
                    }

                    blitfenetre(positionMenu1,screen,1,menu1,&hero,&c);
                    blitminihero(screen,&mh);
                    deplacer (&mh,&hero);
                    mh.directiondep = 1;

}

if ( r == 2 )
{
                    hero.directionjump = 2;
                    deplacerjoueur(&hero,2);
		    if(Bounding_Box(&hero.heroposition,&enemie2.tpos) == 1 )
                    {}
                    else
                    {
                        scrollingb (&c,&hero);
                        enemie2.tpos.x+=15;
                        enemie1.tpos.x+=15;
                        coins[0].tpos.x+=15;
                        coins[1].tpos.x+=15;
                        coins[2].tpos.x+=15;
                    }
                    blitfenetre(positionMenu1,screen,2,menu1,&hero,&c);
                    blitminihero(screen,&mh);
                    deplacer (&mh,&hero);
                    mh.directiondep = 2;
}

if ( r == 3 )
{
                    hero.heroisjumping = 1;
           	    jump (&hero);
}


//////////////////////////////////


////////////////////////////////////////enigme sahar

		if ( c.camera.x == 200 ) 
	{
		ef.resultat_enigme = mainenigmefichier (argc,&argv);
		printf("%d\n",ef.resultat_enigme);
		if ( ef.resultat_enigme == 1 )
		{
			v.updatevie = 0 ;
		}
		if ( ef.resultat_enigme == 0 )
		{
			if ( v.updatevie == 1 ) 
			{
				v.updatevie = 2;
			}
			if ( v.updatevie == 0 ) 
			{
				v.updatevie = 1;
			}

			
		}
		c.camera.x += 10;
                screen = SDL_SetVideoMode(1200,800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
                SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
	}
           	updatevie(&v);




///////////////////////////////////////////////test colission et vie
            if(Bounding_Box(&hero.heroposition,&enemie2.tpos) == 1 )
            {
		if ( bound == 0 )
		{
                	v.updatevie += 1;
			bound = 1 ;
		}
           	updatevie(&v);
            }




///////////////////////////////////////////enigme nardine 
            if ( (c.camera.x == 500) && (testenigme1fois==0) )
            {
                resultat = mainenigme();
                screen = SDL_SetVideoMode(1200,800, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
                testenigme1fois = 1;
                SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY,SDL_DEFAULT_REPEAT_INTERVAL);
		machinegun = Mix_LoadWAV("machine.wav");
                if ( resultat == 1 )
                {
                    blitfenetre(positionMenu1,screen,1,menu1,&hero,&c);
    Afficher_Etites(screen,anim_enemie2,&enemie1,coins,coin,&test,&enemie2,hero.heroposition,&shot);
		    blitvie(&v,screen);
                    blitminihero(screen,&mh);
                    vongratswin(&hero,screen);

                }
            }
		if (resultat == 1 )
		{
			s.score += 500;
                    	affichage_score (&s,score);
			resultat = 0 ;
		}

////////////////////////////////////////////coins et update score


            for(i=0; i<3; i++)
            {
                if(Colllision_Trigo ( hero.heroposition,coins[i].tpos)==1)
                {
                    Mix_PlayChannel(1,coin_sound,0);
                    SDL_Delay(10);
                    coins[i].image=NULL;
                    coins[i].tpos.x=-200;
                    coins[i].tpos.y=-200;

                    s.score += 100;

                    affichage_score (&s,score);
                }

            }

/////////////////////////////////////////////
            jump (&hero);

if (( r == 1) || (r == 2)) 
{
        resetafterjump (&hero,&c);
}




            blitvie(&v,screen);
    Afficher_Etites(screen,anim_enemie2,&enemie1,coins,coin,&test,&enemie2,hero.heroposition,&shot);
            SDL_BlitSurface(s.text, NULL, screen, &(s.positionscore)); /* Blit du texte */
            blitminihero(screen,&mh);




if ( hero.heroisjumping == 0 )
{

        resetafterjump (&hero,&c);

}






	if ( 1000/fps > SDL_GetTicks()-start)
	{
		SDL_Delay(1000/fps-(SDL_GetTicks()-start));
	}

    }
    Mix_FreeChunk(machinegun);
    Mix_CloseAudio();
    SDL_FreeSurface(menu1);
    SDL_FreeSurface(hero.heroright);
    SDL_FreeSurface(hero.heroleft);



}


