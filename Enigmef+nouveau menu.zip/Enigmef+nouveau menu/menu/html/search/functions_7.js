var searchData=
[
  ['play_5fgame',['play_game',['../menu_8c.html#ad974ee303e4aa428506f488c395966b3',1,'play_game(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#ad974ee303e4aa428506f488c395966b3',1,'play_game(menu *m, SDL_Surface *screen):&#160;menu.c']]]
];
