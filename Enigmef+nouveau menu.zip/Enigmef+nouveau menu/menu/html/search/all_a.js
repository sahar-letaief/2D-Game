var searchData=
[
  ['rect',['rect',['../structmenu.html#a320a11bbe2f3002e379c999a66a2ecbd',1,'menu']]],
  ['resume_5fmenu',['resume_menu',['../structmenu.html#a1fe161137a3e1e3189fb59f8e29fac15',1,'menu']]]
];
