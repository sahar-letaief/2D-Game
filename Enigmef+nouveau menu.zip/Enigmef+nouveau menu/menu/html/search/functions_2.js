var searchData=
[
  ['free_5fmenu',['free_menu',['../menu_8c.html#a7245bdaf65fc47fe30e8a91c206bcef7',1,'free_menu(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#a7245bdaf65fc47fe30e8a91c206bcef7',1,'free_menu(menu *m, SDL_Surface *screen):&#160;menu.c']]]
];
