var searchData=
[
  ['init_5fmenu',['init_menu',['../menu_8c.html#a51d5ea252a672871db7e3de21a4a2374',1,'init_menu(menu *m):&#160;menu.c'],['../menu_8h.html#a51d5ea252a672871db7e3de21a4a2374',1,'init_menu(menu *m):&#160;menu.c']]],
  ['intro_5fgame',['intro_game',['../menu_8c.html#aaa81539237541f08e6eb0143317d28a2',1,'intro_game(SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#aaa81539237541f08e6eb0143317d28a2',1,'intro_game(SDL_Surface *screen):&#160;menu.c']]]
];
