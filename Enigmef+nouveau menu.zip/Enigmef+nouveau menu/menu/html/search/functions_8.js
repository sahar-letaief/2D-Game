var searchData=
[
  ['save_5fgame',['save_game',['../menu_8c.html#ad07107ae6556744a3ae0286b1890ab9e',1,'save_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c'],['../menu_8h.html#ad07107ae6556744a3ae0286b1890ab9e',1,'save_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c']]],
  ['selection_5fgame',['selection_game',['../menu_8c.html#a4732c4409b4be373341e853080aa5b8f',1,'selection_game(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#a4732c4409b4be373341e853080aa5b8f',1,'selection_game(menu *m, SDL_Surface *screen):&#160;menu.c']]],
  ['setrect_5fmenu',['setrect_menu',['../menu_8c.html#adb43ea280248d53f903ce93c5442cbc0',1,'setrect_menu(menu *m):&#160;menu.c'],['../menu_8h.html#adb43ea280248d53f903ce93c5442cbc0',1,'setrect_menu(menu *m):&#160;menu.c']]],
  ['story_5fgame',['story_game',['../menu_8c.html#acb3b89af9feb63986e486b7e315de3ca',1,'story_game(SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#acb3b89af9feb63986e486b7e315de3ca',1,'story_game(SDL_Surface *screen):&#160;menu.c']]]
];
