var searchData=
[
  ['save',['save',['../structsave.html',1,'save'],['../menu_8h.html#acf55154a7d0e4399a1ed93473a76869e',1,'save():&#160;menu.h']]],
  ['save_5fgame',['save_game',['../menu_8c.html#ad07107ae6556744a3ae0286b1890ab9e',1,'save_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c'],['../menu_8h.html#ad07107ae6556744a3ae0286b1890ab9e',1,'save_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c']]],
  ['sc',['sc',['../structsave.html#a40860bc57c30dd678218cbb0f47b447d',1,'save']]],
  ['selection_5fgame',['selection_game',['../menu_8c.html#a4732c4409b4be373341e853080aa5b8f',1,'selection_game(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#a4732c4409b4be373341e853080aa5b8f',1,'selection_game(menu *m, SDL_Surface *screen):&#160;menu.c']]],
  ['setrect_5fmenu',['setrect_menu',['../menu_8c.html#adb43ea280248d53f903ce93c5442cbc0',1,'setrect_menu(menu *m):&#160;menu.c'],['../menu_8h.html#adb43ea280248d53f903ce93c5442cbc0',1,'setrect_menu(menu *m):&#160;menu.c']]],
  ['son_5fchoix',['son_choix',['../structmenu.html#a196ac9b9012c40d4712de09ef3a4b7db',1,'menu']]],
  ['son_5fmenu',['son_menu',['../structmenu.html#a86af0fb20f11573b8fcb7bd88c94b17b',1,'menu']]],
  ['sous_5fmenu',['sous_menu',['../structmenu.html#aac0c47096c115f7933c293a8c0ad3153',1,'menu']]],
  ['story_5fgame',['story_game',['../menu_8c.html#acb3b89af9feb63986e486b7e315de3ca',1,'story_game(SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#acb3b89af9feb63986e486b7e315de3ca',1,'story_game(SDL_Surface *screen):&#160;menu.c']]]
];
