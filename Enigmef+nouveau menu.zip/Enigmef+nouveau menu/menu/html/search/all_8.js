var searchData=
[
  ['option_5fgame',['option_game',['../menu_8c.html#a177cc86116725509def3afa146076715',1,'option_game(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#a177cc86116725509def3afa146076715',1,'option_game(menu *m, SDL_Surface *screen):&#160;menu.c']]]
];
