var searchData=
[
  ['ent_5fartif',['ent_artif',['../structsave.html#ac30af48e4fc528ef44dac86275b3ffdb',1,'save']]],
  ['ent_5ffix',['ent_fix',['../structsave.html#a092975e75b34df501ebbf39d9b0ede0c',1,'save']]]
];
