var searchData=
[
  ['animationmenu',['animationmenu',['../menu_8c.html#af7b42d0815b527a95a144e3eb6dc9fac',1,'animationmenu(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#af7b42d0815b527a95a144e3eb6dc9fac',1,'animationmenu(menu *m, SDL_Surface *screen):&#160;menu.c']]]
];
