var searchData=
[
  ['load_5fgame',['load_game',['../menu_8c.html#addfc9cd6b3c56440c42d98ce2084d8ca',1,'load_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c'],['../menu_8h.html#addfc9cd6b3c56440c42d98ce2084d8ca',1,'load_game(save *s, char fichier_entit_artif[], char fichier_entit_fix[], char fichier_camera[], char fichier_score[], char fichier_vie[]):&#160;menu.c']]]
];
