var searchData=
[
  ['chunk',['chunk',['../menu_8c.html#a56a26f330a89cb74500c56f0be7224d4',1,'chunk(menu *m):&#160;menu.c'],['../menu_8h.html#a56a26f330a89cb74500c56f0be7224d4',1,'chunk(menu *m):&#160;menu.c']]],
  ['credits_5fgame',['credits_game',['../menu_8c.html#a3379696bfa7936e199da5571b563acbc',1,'credits_game(menu *m, SDL_Surface *screen):&#160;menu.c'],['../menu_8h.html#a3379696bfa7936e199da5571b563acbc',1,'credits_game(menu *m, SDL_Surface *screen):&#160;menu.c']]]
];
