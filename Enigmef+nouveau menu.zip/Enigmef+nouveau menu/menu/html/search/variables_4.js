var searchData=
[
  ['message_5fttf',['message_ttf',['../structmenu.html#a3320424e52e0e48dab7db99e3ec6af42',1,'menu']]]
];
