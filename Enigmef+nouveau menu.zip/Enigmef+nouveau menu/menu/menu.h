
/**
* @file menu.h
* @brief  fichier header
* @author NOT YET Sahar Letaief 1A3
* @version 1.2
* @date June 2020
*/
#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "enemie.h"
#include "hero.h"



/**
* @struct menu
* @brief structure menu
*/
struct menu
{
SDL_Surface *backg_menu,*sous_menu,*resume_menu,*clip,*message_ttf; /*!< surfaces */
SDL_Rect pos_menu,pos_sous_menu,pos_ttf,pos_resume,rect[21]; /*!< rectengles */
Mix_Music *son_menu; /*!< son menu*/
Mix_Chunk *son_choix; /*!< mix chunk*/
TTF_Font *police_ttf; /*!< ttf font*/
int frame,choix; /*!<frame pour les spritesheets, choix pour le choix des options*/

}; 
typedef struct menu menu;
 


/**
* @struct save
* @brief struct pour la sauvegarde des positions
*/

struct save
{
FILE *f1,*f2,*f3,*f4; /*!< fichiers binaires pour la sauvegarde*/
camera *cam; 
entite_second_artif *ent_artif;
entite_second_fix *ent_fix;
score *sc;
vie *vie;

};
typedef struct save save;



void load_game(save *s,char fichier_entit_artif[],char fichier_entit_fix[],char fichier_camera[],char fichier_score[],char fichier_vie[]);
void save_game(save *s,char fichier_entit_artif[],char fichier_entit_fix[],char fichier_camera[],char fichier_score[],char fichier_vie[]);

void intro_game(SDL_Surface *screen);
void story_game(SDL_Surface *screen);

void init_menu(menu* m);
void selection_game(menu* m ,SDL_Surface *screen);
void play_game(menu* m ,SDL_Surface *screen);
int option_game(menu* m,SDL_Surface *screen);
void message_ttf(menu *m,SDL_Surface *screen);
void credits_game(menu *m,SDL_Surface *screen);
void chunk(menu *m);

void animationmenu(menu* m,SDL_Surface *screen);
void setrect_menu( menu *m);

void free_menu(menu *m,SDL_Surface *screen);
















#endif

