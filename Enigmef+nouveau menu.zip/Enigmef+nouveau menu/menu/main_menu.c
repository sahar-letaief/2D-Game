/**
* @file main.c
* @brief  main for menu
* @author NOT YET Sahar Letaief 1A3
* @version 1.2
* @date June 2020
*/


#include <stdlib.h>
#include <stdio.h>

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

#include "hero.h"
#include "enemie.h"
#include "menu.h"
#include "enemiepartage.h"




int main (int argc , char *argv[])
{

int continuer = 3,continuer_p=1;
SDL_Surface *screen = NULL;
menu m;
SDL_Event event;

SDL_Init(SDL_INIT_EVERYTHING);



	screen = SDL_SetVideoMode(1200,800,32,SDL_HWSURFACE | SDL_DOUBLEBUF);

    intro_game(screen);
    init_menu(&m);
    setrect_menu( &m);
while (continuer)

{

        //message_ttf(&m,screen);
	SDL_WaitEvent(&event);
     	switch (event.type)
	{
	case SDL_QUIT:
	continuer =0 ;
 	break;

	case SDL_KEYDOWN:

	switch (event.key.keysym.sym)
	{
	case SDLK_ESCAPE :
	continuer =0 ;
	break;


	case SDLK_p:
        {
         while(continuer_p)
         {
        printf("bouton p\n");
        chunk(&m);
        play_game(&m,screen);
        SDL_Delay(15000);
        continuer_p=0;
         }
        }
	break;
        case SDLK_o:
        {
                printf("bouton o\n");
                chunk(&m);
               m.choix=option_game(&m,screen);
        }
        break;
        case SDLK_q: 
        {
         printf("bouton q\n");
         chunk(&m);
         continuer=0;
        }
        break;
        case SDLK_c:
        {
          printf("bouton c\n");
          chunk(&m);
          credits_game(&m,screen);
        }
        break;
        /*case SDLK_f :
        {
          printf("bouton f\n");
          full screennnnnnnnnnnnn
        } break;*/

	}
        break;
        case SDL_MOUSEBUTTONDOWN:
        switch(event.button.button)         
        {
           case SDL_BUTTON_LEFT:
           {
               if(event.button.x>117&&event.button.x<249&&event.button.y>180&&event.button.y<223)//play
                   {
                                   while(continuer_p)
                                    {
                                   printf("bouton p\n");
                                   chunk(&m);
                                   play_game(&m,screen);
                                   //SDL_Delay(15000);
                                   continuer_p=0;
                                    }
                   }
                if(event.button.x>70&&event.button.x<298&&event.button.y>288&&event.button.y<331) //option
                   {
                                  printf("option mouse\n");
                                  chunk(&m);
                                  m.choix=option_game(&m,screen);
                   }
               if(event.button.x>71.8&&event.button.x<296.8&&event.button.y>405&&event.button.y<448) //credits
                {
                    printf("credits mouse\n");
                    chunk(&m);
                   credits_game(&m,screen);
                }
               if(event.button.x>120.5&&event.button.x<248&&event.button.y>525&&event.button.y<568) //quit
                {
                    printf("quit mouse\n");
                    chunk(&m);
                    continuer=0;
                }
           } break; // button left
        }
             
         break; //case mouse down
 	}


        message_ttf(&m,screen);
       // SDL_BlitSurface(m.backg_menu,&m.rect[m.frame],screen,&m.pos_menu);
        SDL_Flip(screen);
        animationmenu(&m,screen);
       /* (m.frame)++;
		if(m.frame==2)
 		{
			m.frame=0;
		}*/

}

free_menu(&m,screen);
SDL_Quit();
return EXIT_SUCCESS;
}
