/**
* @file menu.c
* @brief  fichier source de menu
* @author NOT YET Sahar Letaief 1A3
* @version 1.2
* @date June 2020
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h> 

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

#include "menu.h"
#include "hero.h"
#include "heropartage.h"
#include "enemie.h"
#include "enigme1.h"

/**
* @brief intro game
* @param screen
* @return nothing
*/
void intro_game(SDL_Surface *screen)
{
SDL_Surface* intro;
SDL_Rect positionintro;
positionintro.x = 0;
positionintro.y = 0;
int run = 0;

SDL_Rect positionscreen;
positionscreen.x = 0;
positionscreen.y = 0;
positionscreen.w = 1200;
positionscreen.h = 800;


intro = IMG_Load ("intro1.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
while (run!= 1 )
{

	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro2.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro3.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro4.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro5.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro6.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro7.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro8.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(200);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro9.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro10.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro11.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro12.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro13.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro14.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro15.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro16.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(400);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro17.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(500);

	SDL_FreeSurface(intro);
	intro = IMG_Load ("intro18.png");
	SDL_BlitSurface(intro,NULL,screen,&positionintro);
	SDL_Flip(screen);
	SDL_Delay(4000);
	run = 1;

	SDL_FreeSurface(intro);
}
}


/**
* @brief story game
* @param screen
* @return nothing
*/

void story_game(SDL_Surface *screen)
{
SDL_Surface* storytime;
SDL_Rect positionstory;
positionstory.x = 0;
positionstory.y = 0;
int runstory = 0;



storytime = IMG_Load ("story1.png");

SDL_FreeSurface(screen);
while (runstory!=1 )
{
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story2.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story3.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story4.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story5.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story6.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story7.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story8.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story9.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story10.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story11.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story12.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story13.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story14.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(300);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story27.png");///////////////////////////////////////////27
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(1500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story15.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story16.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story17.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story19.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story20.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story21.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story22.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story23.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story24.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story25.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story26.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(350);


	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story27.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(1500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story28.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2000);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story29.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story30.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2000);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story31.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story32.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2000);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story33.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2200);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story34.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story35.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(3500);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story36.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2000);

	SDL_FreeSurface(storytime);
	storytime = IMG_Load ("story27.png");
	SDL_BlitSurface(storytime,NULL,screen,&positionstory);
	SDL_Flip(screen);
	SDL_Delay(2000);

	SDL_FreeSurface(storytime);

runstory=1;
}
}


/** 
* @brief initialisation du menu
* @param struct menu 
* @return nothing
*/
void init_menu(menu* m)
{

  SDL_Init(SDL_INIT_EVERYTHING);
  SDL_WM_SetCaption("GAME",NULL);
  m->backg_menu=IMG_Load("background menu.png");
  if(!m->backg_menu)
    printf("unable to download menu pic %s\n",SDL_GetError());
  Mix_OpenAudio(22050,MIX_DEFAULT_FORMAT,2,4096);
  if(Mix_OpenAudio(22050,MIX_DEFAULT_FORMAT,2,4096)==-1)
    printf("couldn't open music :%s",SDL_GetError());
  m->son_menu=Mix_LoadMUS("music_game.mp3"); 
  Mix_PlayMusic(m->son_menu,-1); 
  m->son_choix= Mix_LoadWAV("click_option.wav");

  
  m->frame=0;
  m->choix=1;

  m->sous_menu=NULL;
  m->police_ttf=NULL;

  m->pos_ttf.x=750;
  m->pos_ttf.y=760;
  m->pos_ttf.h=37.5;
  m->pos_ttf.w=384;
 
  m->pos_menu.x=0;
  m->pos_menu.y=0;
  m->pos_sous_menu.x=452;
  m->pos_sous_menu.y=230;
  m->pos_resume.x=652;
  m->pos_resume.y=29;
 
}
/** 
* @brief selection of game multi or single player 
* @param struct menu + screen
* @return nothing
*/
void selection_game(menu* m ,SDL_Surface *screen)
{ 
  m->sous_menu=NULL; 
  m->sous_menu=IMG_Load("selection.png");
  if(!m->sous_menu)
       printf("unable to set selection menu %s\n",SDL_GetError());
   SDL_BlitSurface(m->sous_menu,NULL,screen,&(m->pos_sous_menu));
   SDL_Flip(screen);
}


/** 
* @brief affichage play menu  
* @param struct menu + screen
* @return nothing
*/
void play_game(menu* m,SDL_Surface *screen)
{
 SDL_Event event_p1,event_p2;
 int continuer=1 ,CONT=1;
 save s;
 char fichier_camera[10],fichier_enemie_shot[10],fichier_entit_fix[10],fichier_entit_artif[10],fichier_score[10];

  while(continuer)
{   
   selection_game(m ,screen);
   SDL_WaitEvent(&event_p1);
   if(event_p1.type==SDL_MOUSEBUTTONDOWN)
   {
     if(event_p1.button.button==SDL_BUTTON_LEFT)
       {
        if(event_p1.button.x>879&&event_p1.button.x<1049.5&&event_p1.button.y>355&&event_p1.button.y<451.3) //multi
          {
                printf("jouer multi\n");
                 chunk(m);
            	jouerpartage(screen);
          } //if multi
  
       if(event_p1.button.x>540.3&&event_p1.button.x<616&&event_p1.button.y>370&&event_p1.button.y<448.5) //single
        {
         printf("single play\n");
         chunk(m);
        m->resume_menu=IMG_Load("resume.png");
        if(!m->resume_menu)
            printf("unable to set resume menu %s\n",SDL_GetError());
        SDL_BlitSurface(m->resume_menu,NULL,screen,&(m->pos_resume));
        SDL_Flip(screen);
        printf("yes or no\n");
         while(CONT)
          {
        SDL_WaitEvent(&event_p2);
        if(event_p2.type==SDL_MOUSEBUTTONDOWN)
        {
           printf("menu sghayer\n");
          if(event_p2.button.x>755&&event_p2.button.x<896.5&&event_p2.button.y>178&&event_p2.button.y<221) //yes
                { 
                       printf("yes\n");
                       chunk(m);
                       jouer(screen);                       
                }
          else if(event_p2.button.x>990&&event_p2.button.x<1102.5&&event_p2.button.y>178&&event_p2.button.y<217) //no
                {
                       printf("no\n");
                       chunk(m);
                       story_game(screen);
                       jouer(screen); 
               
                }          
     } //event.button.button
     } //event.type2     
     } //if single
            CONT=0; 
   } //while CONT
   } //if event.type1
       // continuer=0;
   } //continuer
        SDL_FreeSurface(m->sous_menu);
        SDL_FreeSurface(m->resume_menu);
} 

/** 
* @brief affichage du menu option 
* @param struct menu + screen
* @return int
*/
int option_game(menu* m ,SDL_Surface *screen)
{
       SDL_Event event_o;
       int test_music=0,CONT=1,continuer=1;

       m->sous_menu=NULL;
       m->sous_menu=IMG_Load("option.png");
       if(!m->sous_menu)
        printf("unable to set option menu %s\n",SDL_GetError());
       
       while(CONT)
        {
       SDL_WaitEvent(&event_o);
            if(event_o.type==SDL_MOUSEBUTTONDOWN)
            {
                        if(event_o.button.button==SDL_BUTTON_LEFT)
                          {
          
              if((test_music==0)&&(event_o.button.x>523.5&&event_o.button.x<583.5&&event_o.button.y>456.8&&event_o.button.y<524.4)) //music off
                {
                       printf("music free\n");
                       chunk(m);
                       Mix_FreeMusic(m->son_menu); 
                       test_music=1;
                       CONT=0;
                      
                } 
              if(event_o.button.x>686&&event_o.button.x<722.2&&event_o.button.y>380.7&&event_o.button.y<464.7) //joystick
                {
                        printf("joystick\n");
                        chunk(m);
                        m->choix=2;
                       CONT=0;
                }
              if(event_o.button.x>882&&event_o.button.x<1030&&event_o.button.y>327.3&&event_o.button.y<412.8) //mouse+keyboard
                {
                       chunk(m);
                       printf("mouse+keyboard\n");
                       m->choix=1;
                       CONT=0;
                }
 
            }

            }  //mouse
 SDL_BlitSurface(m->sous_menu,NULL,screen,&(m->pos_sous_menu));
       SDL_Flip(screen);
          } //while CONT
   SDL_FreeSurface(m->sous_menu);
   return (m->choix);
}
/** 
* @brief initialisation de l'enigme 
* @param struct enigme + screen
* @return nothing
*/

void credits_game(menu* m,SDL_Surface *screen)
{
 int continuer=1;

  m->sous_menu =NULL;
  m->sous_menu=IMG_Load("credits.png");
  if(!m->sous_menu)
    printf("couldn't open credits pic :%s\n",SDL_GetError());
  while(continuer)
  {
  SDL_BlitSurface(m->sous_menu,NULL,screen,&(m->pos_sous_menu));
  SDL_Flip(screen);
  SDL_Delay(7000);
  continuer=0;
  }
}
  
/** 
* @brief affichage d'un message ttf
* @param struct menu + screen
* @return nothing
*/
void message_ttf(menu *m,SDL_Surface *screen)
{
  TTF_Init();
  if(TTF_Init() == -1)
         { 
            fprintf(stderr, "Erreur d'initialisation de TTF_Init : %s\n", TTF_GetError());
            exit(EXIT_FAILURE);
         }
    
    SDL_Color white = {255,255,255};
    m->police_ttf=TTF_OpenFont("fullscreen.ttf",23);
    m->message_ttf= TTF_RenderText_Blended(m->police_ttf,"Press (f) for full screen",white);
    SDL_BlitSurface(m->message_ttf,NULL,screen,&(m->pos_ttf));
    //SDL_Flip(screen);
    
}




/** 
* @brief suspendre le jeu
* @param struct save+fichiers pour les positions du hero et des entités
* @return nothing
*/

void load_game(save *s,char fichier_entit_artif[],char fichier_entit_fix[],char fichier_camera[],char fichier_score[],char fichier_vie[])
{

 
  s->f1=fopen(fichier_camera,"rb");
  s->f2=fopen(fichier_entit_artif,"rb");
  s->f3=fopen(fichier_entit_fix,"rb");
  s->f4=fopen(fichier_score,"rb");
  s->f5=fopen(fichier_vie,"rb");
   
  if(s->f1==NULL)
    printf("unable to open file for camera(load):%s\n",SDL_GetError());
  else
  {
      fread(&(s->cam),sizeof(SDL_Rect),1,s->f1);
  } //else

  if(s->f2==NULL)
    printf("unable to open file for entit artif(load):%s\n",SDL_GetError());
  else
  { 
    fread(&(s->ent_artif->tpos),sizeof(SDL_Rect),1,s->f2);
  } //else

  if(s->f3==NULL)
    printf("unable to open file for entit fix(load):%s\n",SDL_GetError());
  else
  {
    fread(&(s->ent_fix->tpos),sizeof(SDL_Rect),1,s->f3);
  } //else

 
  if(s->f4==NULL)
     printf("unable to open file for score (load):%s\n",SDL_GetError()); 
  else 
  {
   fwrite(&(s->sc->score),sizeof(int),1,s->f5);
  } //else
  
  if(s->f5==NULL)
     printf("unable to open file for vie (load):%s\n",SDL_GetError()); 
  else
  {
    fread(&(s->vie->updatevie),sizeof(int),1,s->f6);
  } //else


  fclose(s->f1);
  fclose(s->f2);
  fclose(s->f3);
  fclose(s->f4);
  

}

/** 
* @brief sauvegarder le jeu
* @param struct save+fichiers pour les positions du hero et des entités
* @return nothing
*/
void save_game(save *s,char fichier_entit_artif[],char fichier_entit_fix[],char fichier_camera[],char fichier_score[],char fichier_vie[])
{
  s->f1=NULL;
  s->f2=NULL;
  s->f3=NULL;
  s->f4=NULL;
  s->f5=NULL;
  
   
  s->f1=fopen(fichier_camera,"wb");
  s->f2=fopen(fichier_entit_artif,"wb");
  s->f3=fopen(fichier_entit_fix,"wb");
  s->f4=fopen(fichier_score,"wb");
  s->f5=fopen(fichier_vie,"wb");
  
  if(s->f1==NULL)
    printf("unable to open file for camera(save):%s\n",SDL_GetError());
  else
  {
      fwrite(&(s->cam),sizeof(SDL_Rect),1,s->f1);
  } //else

  if(s->f2==NULL)
    printf("unable to open file for entit artif(save):%s\n",SDL_GetError());
  else
  { 
    fwrite(&(s->ent_artif->tpos),sizeof(SDL_Rect),1,s->f2);
  } //else

  if(s->f3==NULL)
    printf("unable to open file for entit fix(save):%s\n",SDL_GetError());
  else
  {
    fwrite(&(s->ent_fix->tpos),sizeof(SDL_Rect),1,s->f3);
  } //else

  if(s->f4==NULL)
     printf("unable to open file for score (save):%s\n",SDL_GetError()); 
  else 
  {
   fwrite(&(s->sc->score),sizeof(int),1,s->f5);
  } //else
  
  if(s->f5==NULL)
     printf("unable to open file for vie (save):%s\n",SDL_GetError()); 
  else
  {
    fwrite(&(s->vie->updatevie),sizeof(int),1,s->f6);
  } //else


  fclose(s->f1);
  fclose(s->f2);
  fclose(s->f3);
  fclose(s->f4);
  fclose(s->f5);
}

/** 
* @brief ajuster les spritesheets du background du menu 
* @param struct menu
* @return nothing
*/

void setrect_menu( menu *m)
{
        int i;
	for (i=0;i<21;i++)
	{
		m->rect[i].x = 0;
		m->rect[i].y = 0;
		m->rect[i].w = 0;
		m->rect[i].h = 0;
	}

		m->rect[0].x = 0;
		m->rect[0].y = 0;
		m->rect[0].w = 1199;
		m->rect[0].h = 800;

		m->rect[5].x = 1200;
		m->rect[5].y = 0;
		m->rect[5].w = 1693;
		m->rect[5].h = 800;

		m->rect[10].x = 2399;
		m->rect[10].y = 0;
		m->rect[10].w = 1199;
		m->rect[10].h = 800;

		m->rect[15].x = 3599;
		m->rect[15].y = 0;
		m->rect[15].w = 1199;
		m->rect[15].h = 800;

		m->rect[20].x = 4799;
		m->rect[20].y = 0;
		m->rect[20].w = 1199;
		m->rect[20].h = 800;


}

/** 
* @brief animation des spritesheets du background du menu
* @param struct menu+ screen
* @return nothing
*/
void animationmenu(menu* m,SDL_Surface *screen)
{

	SDL_BlitSurface(m->backg_menu,&(m->rect[m->frame]),screen,&m->pos_menu);
        SDL_Flip(screen);
        SDL_Delay(5);
	m->frame++;

	if ( m->frame ==20 ) 
	{
		m->frame = 0;
	}
}


/** 
* @brief chunk music
* @param struct menu
* @return nothing
*/
void chunk(menu *m)
{
      Mix_PlayChannel(1,m->son_choix,0);
      SDL_Delay(900);
      //Mix_FreeChunk(m->son_choix);
     
}
/** 
* @brief free les surfaces
* @param struct menu+screen
* @return nothing
*/
void free_menu(menu *m,SDL_Surface *screen)
{
    SDL_FreeSurface(m->backg_menu);
    Mix_FreeMusic(m->son_menu);
    Mix_FreeChunk(m->son_choix); 
    SDL_FreeSurface(m->sous_menu);
    SDL_FreeSurface(m->resume_menu);
    SDL_FreeSurface(m->message_ttf);
    TTF_CloseFont(m->police_ttf);
    TTF_Quit();
    SDL_FreeSurface(screen);    
    
}
  
