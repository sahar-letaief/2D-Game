/**
* @file main_enigmef.c
* @brief  enigme avec fichier main
* @author NOT YET Sahar Letaief 1A3
* @version 0.1
* @date June 2020

*/

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "enigmefichier.h"
#include <math.h>






int main_enigmefichier (int argc, char *argv[])
{

    enigmef enigme;

    SDL_Surface *screen=NULL;
    int continuer=1,alea,solution,resolution,run=1,CONT=1,resultatenigme,chance=0;
    char image[20];
    SDL_Event event;
    SDL_Init(SDL_INIT_VIDEO);
    screen= SDL_SetVideoMode(720,480,32,SDL_HWSURFACE | SDL_DOUBLEBUF);
    if(!screen)
    {
        printf("unable to set 720x480 video:> %s\n",SDL_GetError());
    }

    initialiser_enigme_fichier(&enigme,screen);
    Mix_PlayMusic(enigme.son_enigme,-1); 
    afficher_enigmef_alea (&enigme,image,alea,screen);


    while(CONT)
    {
        while(continuer)
        {

            SDL_PollEvent(&event);
            enigme.fichier_q=fopen("resolution.txt","a+");
            if(enigme.fichier_q==NULL)
            {
                printf("unable to open file for resolution:>%s\n",SDL_GetError());
            }
            else
            {

                while(continuer)
                {
                    SDL_PollEvent(&event);
                    switch(event.type)
                    {
                    case SDL_QUIT:
                    {
                        SDL_Quit();
                        continuer=0;
                    }
                    break ;
                    case SDL_KEYDOWN :
                    {
                        switch( event.key.keysym.sym )
                        {
                        case  SDLK_a:
                        {
                            resolution= 1;
                            fprintf(enigme.fichier_q,"la resolution du choix A (avec clavier) est %d\n",resolution);
                            printf("bouton a\n");
                            continuer=0;
                        }
                        break ;
                        case  SDLK_b :
                        {
                            resolution= 2;
                            fprintf(enigme.fichier_q,"la resolution du choix B (avec clavier) est %d\n",resolution);
                            printf("bouton b \n");
                            continuer=0;
                        }
                        break;
                        case SDLK_c :
                        {
                            resolution=3 ;
                            fprintf(enigme.fichier_q,"la resolution du choix C (avec clavier) est %d\n",resolution);
                            printf("bouton c \n");
                            continuer=0;
                        }
                        break;
                        }
                    }
                    break;

                    case SDL_MOUSEBUTTONDOWN :
                    {
                        switch(event.button.button)
                        {
                        case SDL_BUTTON_LEFT :
                        {
                            if(event.button.x>45&&event.button.x<64&&event.button.y>345&&event.button.y<366)
                            {
                                resolution= 1;
                                fprintf(enigme.fichier_q,"la resolution du choix A (avec souris) est %d\n",resolution);
                                printf("souris a\n");
                                continuer=0;
                            }
                            else if(event.button.x>300&&event.button.x<319&&event.button.y>415&&event.button.y<436)
                            {
                                resolution=2;
                                fprintf(enigme.fichier_q,"la resolution du choix B (avec souris) est %d\n",resolution);
                                printf("souris b\n");
                                continuer=0;
                            }
                            else if(event.button.x>545&&event.button.x<564&&event.button.y>340&&event.button.y<361)
                            {
                                resolution=3;
                                fprintf(enigme.fichier_q,"la resolution du choix C (avec souris) est %d\n",resolution);
                                printf("souris c\n");
                                continuer=0;
                            }
                        }
                        break;
                        }
                    }
                    break;
                    }
                }
                fclose(enigme.fichier_q);
            }// else
            solution=solution_enigmef(&enigme,image,screen);
            enigme.resultat_enigme=afficher_resultat_enigmef (&enigme,resolution,solution);
           if(enigme.resultat_enigme==0)
          {
             
           afficher_enigmef_alea ( &enigme,image,alea,screen);
          }
        }//while sghira
            SDL_BlitSurface(enigme.background_enigme,NULL,screen,&(enigme.position_enigme));
            SDL_BlitSurface(enigme.resultat, NULL,screen, &(enigme.pos_resultat)) ;
            SDL_Flip(screen);
            SDL_Delay(2000);
            CONT=0;
} //while kbira
        SDL_FreeSurface(enigme.background_enigme);
        SDL_FreeSurface(enigme.resultat);
        SDL_FreeSurface(screen); 
        SDL_Quit();
        return EXIT_SUCCESS;
}
