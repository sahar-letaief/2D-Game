/**
* @file enigmefichier.c
* @brief  enigme avec fichier source
* @author NOT YET Sahar Letaief 1A3
* @version 0.1
* @date June 2020
*/

#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include <string.h>
#include <math.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "enigmefichier.h"

/** 
* @brief initialisation de l'enigme 
* @param struct enigme + screen
* @return nothing
*/
void initialiser_enigme_fichier( enigmef *enigme,SDL_Surface* screen)
{
     enigme->background_enigme=NULL;
     enigme->position_enigme.x=0;
     enigme->position_enigme.y=0;
     enigme->pos_resultat.x=0;
     enigme->pos_resultat.y=0;
     enigme->resultat=NULL;
     enigme->fichier_q=NULL;
     enigme->fichier_a=NULL;
     enigme->son_enigme=Mix_LoadMUS("music_background.mp3");  
     SDL_WM_SetCaption("enigme avec fichier",NULL);
    
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
{
printf("unable to set music:>%s\n",SDL_GetError());
}

  
enigme->son_enigme=Mix_LoadMUS("music_background.mp3");  
if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
{
printf("unable to set music >:%s\n",SDL_GetError());
}  
  
}
 
/**
* @brief affichage aleatoire de l'enigme 
* @param strcut enigme+screen
* @param image nom de l'enigme 
* @param alea nombre choisi aleatoirement 
*/
void afficher_enigmef_alea ( enigmef *enigme,char image[],int alea,SDL_Surface *screen)
{ 
  
   
 do
 {
  alea=rand()%3+1;
 
 }while(alea>3 || alea<1);
 sprintf(image ,"enigme%d.png",alea);

   enigme->background_enigme= IMG_Load(image);
   SDL_BlitSurface(enigme->background_enigme,NULL,screen,&(enigme->position_enigme)) ;
   SDL_Flip(screen);   
}

/**
* @brief fonction qui retourne la valeur de la solution de l'enigme
* @param strcut enigme+screen
* @param image nom de l'enigme choisi
* @return int
*/
int solution_enigmef (enigmef *enigme,char image[],SDL_Surface *screen) 
 {
 	int solution =4;
        enigme->fichier_a=fopen("solution.txt","a+");
        if(enigme->fichier_a==NULL)
        printf("unable to open file:>%s\n",SDL_GetError());
        else
        {
        
 	if(strcmp(image,"enigme1.png")==0)
 	{
                 solution =1 ;
                 fprintf(enigme->fichier_a,"la solution de l'enigme 1 est %d\n",solution);
printf("enigme1\n");
 	}
 	else  	if(strcmp(image,"enigme2.png")==0)
 	{
 		solution =2;
                fprintf(enigme->fichier_a,"la solution de l'enigme 2 est %d\n",solution);
printf("enigme2\n");
 	}
 	else 	if(strcmp(image,"enigme3.png")==0)
 	{
 		solution =3;	
                fprintf(enigme->fichier_a,"la solution de l'enigme 3 est %d\n",solution);
printf("enigme3\n");
 	}
        }
      fclose(enigme->fichier_a);
 	return solution;
}


/**
* @brief affichage du resultat de l'enigme selon les valeurs de la solution et de la resolution
* @param strcut enigme+screen
* @param solution+ resolution selon le choix du l'utilisateur
* @return int
*/
int afficher_resultat_enigmef (enigmef* enigme,int resolution,int solution)
 {         
            Mix_Chunk *truee,*falsee;
            enigme->pos_resultat.x=220;
            enigme->pos_resultat.y=150;
            falsee= Mix_LoadWAV("wrong.wav");
            truee= Mix_LoadWAV("correct.wav");
 	
 	if (resolution==solution)
 	{
                  Mix_PlayChannel(1,truee,0);
                  SDL_Delay(800);
 		 enigme->resultat=IMG_Load("you win.png");
                if(enigme->resultat==NULL)
                    printf("unable to open you win picture:>%s\n",SDL_GetError());
               Mix_FreeChunk(truee);
               enigme->resultat_enigme=1;
 	}
 	else
 	{
      Mix_PlayChannel(1,falsee,0);
                  SDL_Delay(800);
   enigme->resultat=IMG_Load("you lose.png");
                if(enigme->resultat==NULL)
                    printf("unable to open you lose picture:>%s\n",SDL_GetError());
               Mix_FreeChunk(falsee);                
               enigme->resultat_enigme=0;
 	}  
         return (enigme->resultat_enigme);    
}



