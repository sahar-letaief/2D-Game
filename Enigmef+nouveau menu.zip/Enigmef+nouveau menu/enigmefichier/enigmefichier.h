#ifndef ENIGMEFICHIER_H_
#define ENIGMEFICHIER_H_
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>

/**
* @struct enigmef
* @brief structure pour enigme avec fichier
*/

struct enigmef
{
SDL_Surface *background_enigme,*resultat; /*!<surface for background+ for result*/ 
SDL_Rect position_enigme,pos_resultat; /*!< postions of background and result*/
Mix_Music *son_enigme; /*! <background sound*/ 
FILE *fichier_q;   /*!<file for questions*/ 
FILE *fichier_a;   /*!<file for answers*/
int resultat_enigme; /*!< enigme result*/
};
typedef struct enigmef enigmef;



void initialiser_enigme_fichier( enigmef *enigme,SDL_Surface *screen);
void afficher_enigmef_alea ( enigmef *enigme,char image[],int alea,SDL_Surface *screen);
int solution_enigmef (enigmef *enigme,char image[],SDL_Surface *screen) ;
int afficher_resultat_enigmef (enigmef* enigme,int resolution,int solution);



#endif
