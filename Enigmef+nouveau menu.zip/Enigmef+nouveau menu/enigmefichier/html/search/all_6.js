var searchData=
[
  ['pos_5fresultat',['pos_resultat',['../structenigmef.html#a19eadfa4e7f5d95f7e76fadadddffecb',1,'enigmef']]],
  ['position_5fenigme',['position_enigme',['../structenigmef.html#ae4fe278172e57b22e71213ba7eedf3b5',1,'enigmef']]]
];
