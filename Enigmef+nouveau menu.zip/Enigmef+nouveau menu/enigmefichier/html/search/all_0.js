var searchData=
[
  ['afficher_5fenigmef_5falea',['afficher_enigmef_alea',['../enigmefichier_8c.html#aa851c06b3f7440a6f00f6128a635f429',1,'afficher_enigmef_alea(enigmef *enigme, char image[], int alea, SDL_Surface *screen):&#160;enigmefichier.c'],['../enigmefichier_8h.html#aa851c06b3f7440a6f00f6128a635f429',1,'afficher_enigmef_alea(enigmef *enigme, char image[], int alea, SDL_Surface *screen):&#160;enigmefichier.c']]],
  ['afficher_5fresultat_5fenigmef',['afficher_resultat_enigmef',['../enigmefichier_8c.html#ae8cf327f322df83b1f23174cf7ff0935',1,'afficher_resultat_enigmef(enigmef *enigme, int resolution, int solution):&#160;enigmefichier.c'],['../enigmefichier_8h.html#ae8cf327f322df83b1f23174cf7ff0935',1,'afficher_resultat_enigmef(enigmef *enigme, int resolution, int solution):&#160;enigmefichier.c']]]
];
