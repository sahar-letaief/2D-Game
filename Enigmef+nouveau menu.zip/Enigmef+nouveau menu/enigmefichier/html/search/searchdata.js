var indexSectionsWithContent =
{
  0: "abefimprs",
  1: "e",
  2: "em",
  3: "aims",
  4: "bfprs",
  5: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs"
};

